public class Ladino extends Humanoide implements Action{

    public Ladino() {
        vida = 15;
        nome = "Ladino";
        atk = 7;
        xp = 0;
    }
    
    public void atacar(Humanoide humano){
        humano.vida = humano.vida - this.atk;
    }

    public void atacar(Monstro monstro){
       monstro.vida = monstro.vida - this.atk; 
    }
    
    public void defender(Humanoide humano){
    
    }
    
    public void defender(Monstro monstro){
    
    }
    
      
    
    //Função que retorna o valor da vida
    //usada para ser testada na simulação
    /*public int getVida(){
        return vida;
    }*/
}
