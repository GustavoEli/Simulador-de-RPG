
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Guerreiro guer = new Guerreiro();
        
        /*if(guer.atacar()){
            System.out.println("é positivo");
        }else{
            System.out.println("é negativo");
        }*/
        
        batalhaSim bt = new batalhaSim();
        bt.inicio();
    }
    
}
    