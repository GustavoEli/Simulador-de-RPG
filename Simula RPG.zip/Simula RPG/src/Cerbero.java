public class Cerbero extends Monstro implements Action{

    public Cerbero() {
        vida = 15;
        nome = "Cerbero";
        atk = 12;
    }
    
    public void atacar(Humanoide humano){
        humano.vida = humano.vida - this.atk;
    }

    public void atacar(Monstro monstro){
       monstro.vida = monstro.vida - this.atk; 
    }
    
    public void defender(Humanoide humano){
    
    }
    
    public void defender(Monstro monstro){
    
    }
    
      
    
    /*public int getVida(){
        return vida;
    }*/
}
