public class Monstro implements Action{
    
    int vida;
    String nome;
    int atk;
    
    public Monstro(){
        
    }
    
    public void atacar(Humanoide humanos){}
    
    public void atacar(Monstro criatura){}
    
    public void defender(Humanoide humanos){}
    
    public void defender(Monstro criatura){}
    
    /*public int getVida(){
        return vida;
    }*/
}