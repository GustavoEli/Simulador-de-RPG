public interface Action {
    
    public void atacar(Humanoide humanos);
    public void atacar(Monstro criatura);
    public void defender(Humanoide humanos);
    public void defender(Monstro criatura);
    
    
}
