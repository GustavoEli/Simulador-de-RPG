public class Guerreiro extends Humanoide implements Action{
    
    public Guerreiro(/*int vida, int xp*/) {
    //super(vida, xp);
    //definindo os atributos herdados de humanoide para essa classe
        vida = 20;
        nome = "Guerreiro";
        atk = 7;
        xp = 0;
    }
    
    
    public void atacar(Humanoide humano){
        humano.vida = humano.vida - this.atk;
    }

    public void atacar(Monstro monstro){
       monstro.vida = monstro.vida - this.atk;
    }
    
    public void defender(Humanoide humano){
    
    }
    
    public void defender(Monstro monstro){
    
    }
    
    
    
    //Função que retorna o valor da vida
    //usada para ser testada na simulação
    /*public int getVida(){
        return vida;
    }*/
}
