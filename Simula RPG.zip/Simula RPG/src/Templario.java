public class Templario extends Humanoide implements Action{

    public Templario() {
        vida = 20;
        nome = "Templario";
        atk = 7;
        xp = 0;
    }
    
    public void atacar(Humanoide humano){
        humano.vida = humano.vida - this.atk;
    }

    public void atacar(Monstro monstro){
       monstro.vida = monstro.vida - this.atk; 
    }
    
    public void defender(Humanoide humano){
    
    }
    
    public void defender(Monstro monstro){
    
    }
    
    
}
